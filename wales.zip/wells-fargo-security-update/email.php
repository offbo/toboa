<?

$to = "mattbuff2020@protonmail.com,mogulofbitcoin@protonmail.com";

?>